import React from 'react'
import "./FooterComponents.css"

function FooterComponents() {
  return (
    <div>







    </div>
  )
}

export default FooterComponents